import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.fotoPrincipal = "";
		this.nombre = "Sin nombre";
		this.frasePresentacion = "";
		this.texto = "";
		this.seleccionar = new EventEmitter();
	}
	onBotonClick() {
		this.seleccionar.emit(this.nombre);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.5",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				fotoPrincipal: "fotoPrincipal",
				nombre: "nombre",
				frasePresentacion: "frasePresentacion",
				texto: "texto"
			},
			outputs: { seleccionar: "seleccionar" },
			ngImport: i0,
			template: "<div class=\"card\">\n  @if (fotoPrincipal) {\n    <img [src]=\"fotoPrincipal\" [alt]=\"nombre\" class=\"card__foto\" />\n  }\n  <div class=\"card__cuerpo\">\n    <h2 class=\"card__nombre\">{{ nombre }}</h2>\n    <span class=\"card__frase\">{{ frasePresentacion }}</span>\n    <p class=\"card__texto\">{{ texto }}</p>\n\n    <button type=\"button\" class=\"card__boton\" (click)=\"onBotonClick()\">\n      Ver detalles \n    </button>\n  </div>\n</div>\n",
			styles: [":host{display:block;margin:16px auto;max-width:380px}.card{margin:0;overflow:hidden;border:2px solid #569035;border-radius:16px;background:#222a1f;box-shadow:0 4px 16px #7ccd4d33;transition:transform .2s ease,box-shadow .2s ease}.card:hover{box-shadow:0 6px 20px #6ae64b59}.card__foto{display:block;width:100%;height:190px;object-fit:scale-down;padding:10px;border-bottom:2px solid #34442a}.card__cuerpo{padding:16px;text-align:center}.card__nombre{margin:8px 0 6px;color:#7ccd4d;font-size:1.4rem;font-weight:700;letter-spacing:.5px}.card__frase{display:inline-block;margin-bottom:12px;padding:4px 12px;border-radius:999px;background:#34442a;color:#6ae64b;font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;border:1px solid #569035}.card__boton{margin-top:14px;padding:8px 16px;border:1px solid #569035;border-radius:8px;background:#5eca56;color:#171717;font-size:.85rem;font-weight:700;cursor:pointer;transition:background .2s ease,transform .1s ease}.card__texto{margin:0;color:#d4d4d4;font-size:.95rem;line-height:1.5}.card__boton:hover{background:#6ae64b;transform:scale(1.03)}.card__boton:active{transform:scale(.98)}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			imports: [],
			template: "<div class=\"card\">\n  @if (fotoPrincipal) {\n    <img [src]=\"fotoPrincipal\" [alt]=\"nombre\" class=\"card__foto\" />\n  }\n  <div class=\"card__cuerpo\">\n    <h2 class=\"card__nombre\">{{ nombre }}</h2>\n    <span class=\"card__frase\">{{ frasePresentacion }}</span>\n    <p class=\"card__texto\">{{ texto }}</p>\n\n    <button type=\"button\" class=\"card__boton\" (click)=\"onBotonClick()\">\n      Ver detalles \n    </button>\n  </div>\n</div>\n",
			styles: [":host{display:block;margin:16px auto;max-width:380px}.card{margin:0;overflow:hidden;border:2px solid #569035;border-radius:16px;background:#222a1f;box-shadow:0 4px 16px #7ccd4d33;transition:transform .2s ease,box-shadow .2s ease}.card:hover{box-shadow:0 6px 20px #6ae64b59}.card__foto{display:block;width:100%;height:190px;object-fit:scale-down;padding:10px;border-bottom:2px solid #34442a}.card__cuerpo{padding:16px;text-align:center}.card__nombre{margin:8px 0 6px;color:#7ccd4d;font-size:1.4rem;font-weight:700;letter-spacing:.5px}.card__frase{display:inline-block;margin-bottom:12px;padding:4px 12px;border-radius:999px;background:#34442a;color:#6ae64b;font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;border:1px solid #569035}.card__boton{margin-top:14px;padding:8px 16px;border:1px solid #569035;border-radius:8px;background:#5eca56;color:#171717;font-size:.85rem;font-weight:700;cursor:pointer;transition:background .2s ease,transform .1s ease}.card__texto{margin:0;color:#d4d4d4;font-size:.95rem;line-height:1.5}.card__boton:hover{background:#6ae64b;transform:scale(1.03)}.card__boton:active{transform:scale(.98)}\n"]
		}]
	}],
	propDecorators: {
		fotoPrincipal: [{ type: Input }],
		nombre: [{ type: Input }],
		frasePresentacion: [{ type: Input }],
		texto: [{ type: Input }],
		seleccionar: [{ type: Output }]
	}
});
export { MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map