import * as i0 from "@angular/core";
import { EventEmitter } from "@angular/core";
export declare class MonsterCardComponent {
  fotoPrincipal: string;
  nombre: string;
  frasePresentacion: string;
  texto: string;
  seleccionar: EventEmitter<string>;
  onBotonClick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "fotoPrincipal": {
      "alias": "fotoPrincipal";
      "required": false;
    };
    "nombre": {
      "alias": "nombre";
      "required": false;
    };
    "frasePresentacion": {
      "alias": "frasePresentacion";
      "required": false;
    };
    "texto": {
      "alias": "texto";
      "required": false;
    };
  }, {
    "seleccionar": "seleccionar";
  }, never, never, true, never>;
}